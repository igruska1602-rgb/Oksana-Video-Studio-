# Myroniuk Studio — starter Android project

This is an initial Android prototype, not a finished social publishing client.

Included:
- colourful landscape-inspired header and modern creator-studio interface
- select a video from device storage
- choose intended platforms (TikTok, Instagram, Facebook, YouTube)
- local queue saved on the device
- light/dark theme and compact interface settings
- queue items can be removed

Not yet implemented:
- actual posting to social networks or background scheduled publishing
- official API / OAuth integrations
- a complete date/time scheduler
- remote patch delivery / in-app code updates

The app does not impose a hard-coded video size limit. Actual file selection and handling remain subject to Android storage access, available device space, memory, file format, and each social platform's own limits.

Build: use the provided GitHub Actions workflow and upload this project ZIP to the repository root.
