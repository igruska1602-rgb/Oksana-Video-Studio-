package com.myroniuk.studio

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

private val Violet = Color(0xFF6D45F5)
private val Pink = Color(0xFFFF5C9A)
private val Cyan = Color(0xFF4CD7E8)
private val Ink = Color(0xFF18213A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("myroniuk_studio", MODE_PRIVATE)
        setContent {
            var dark by remember { mutableStateOf(prefs.getBoolean("dark", true)) }
            var compact by remember { mutableStateOf(prefs.getBoolean("compact", false)) }
            var selectedPlatforms by remember {
                mutableStateOf(setOf("TikTok", "YouTube"))
            }
            var videos by remember { mutableStateOf(loadVideos(prefs.getString("videos", "[]") ?: "[]")) }
            var status by remember { mutableStateOf("Добавь видео, выбери платформы и подготовь очередь.") }

            fun persist() {
                prefs.edit().putString("videos", saveVideos(videos)).apply()
            }

            val picker = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.OpenDocument()
            ) { uri: Uri? ->
                if (uri != null) {
                    try {
                        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    } catch (_: Exception) { }
                    val name = contentResolver.query(uri, null, null, null, null)?.use { c ->
                        val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (c.moveToFirst() && idx >= 0) c.getString(idx) else null
                    } ?: "Видео ${videos.size + 1}"
                    videos = videos + VideoItem(uri.toString(), name, selectedPlatforms.toList(), "Без даты")
                    persist()
                    status = "Видео добавлено в очередь. Публикация пока не отправляется автоматически."
                }
            }

            MaterialTheme(
                colorScheme = if (dark) darkColorScheme(
                    primary = Color(0xFFB9A7FF),
                    secondary = Cyan,
                    background = Color(0xFF0D1224),
                    surface = Color(0xFF171D33),
                    onBackground = Color(0xFFF6F5FF),
                    onSurface = Color(0xFFF6F5FF)
                ) else lightColorScheme(
                    primary = Violet,
                    secondary = Pink,
                    background = Color(0xFFF4F5FF),
                    surface = Color.White,
                    onBackground = Ink,
                    onSurface = Ink
                )
            ) {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    Column(modifier = Modifier.fillMaxSize()) {
                        LazyColumn(
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 22.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            item {
                                HeroHeader()
                            }
                            item {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(Icons.Default.VideoLibrary, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                                    Text("Твоя видеостудия", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                                }
                                Text("Подготовь ролики и управляй очередью в одном месте.", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f), fontSize = 13.sp)
                            }
                            item {
                                Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                        Text("Куда готовим публикацию?", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                        val platforms = listOf("TikTok", "Instagram", "Facebook", "YouTube")
                                        platforms.chunked(2).forEach { pair ->
                                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                pair.forEach { platform ->
                                                    val checked = platform in selectedPlatforms
                                                    FilterChip(
                                                        selected = checked,
                                                        onClick = {
                                                            selectedPlatforms = if (checked) selectedPlatforms - platform else selectedPlatforms + platform
                                                        },
                                                        label = { Text(platform) },
                                                        modifier = Modifier.weight(1f),
                                                        leadingIcon = if (checked) ({ Icon(Icons.Default.CheckCircle, null, Modifier.size(16.dp)) }) else null
                                                    )
                                                }
                                            }
                                        }
                                        Button(
                                            onClick = { picker.launch(arrayOf("video/*")) },
                                            modifier = Modifier.fillMaxWidth().height(if (compact) 46.dp else 54.dp),
                                            shape = RoundedCornerShape(16.dp)
                                        ) {
                                            Icon(Icons.Default.Add, null)
                                            Spacer(Modifier.width(8.dp))
                                            Text("Добавить видео", fontWeight = FontWeight.Bold)
                                        }
                                        Text("Выбирай видео из памяти телефона. Размер файла ограничивается доступным местом и возможностями Android, а не заданным лимитом приложения.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                                    }
                                }
                            }
                            item {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(Icons.Default.Schedule, contentDescription = null, tint = Pink)
                                    Text("Очередь видео", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.weight(1f))
                                    Surface(shape = CircleShape, color = Violet.copy(alpha = 0.16f)) {
                                        Text("${videos.size}", Modifier.padding(horizontal = 12.dp, vertical = 5.dp), color = if (dark) Color(0xFFD2C7FF) else Violet, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                            if (videos.isEmpty()) {
                                item {
                                    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                                        Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Icon(Icons.Default.Movie, null, Modifier.size(38.dp), tint = MaterialTheme.colorScheme.secondary)
                                            Text("Пока здесь пусто", fontWeight = FontWeight.Bold)
                                            Text("Добавь первое видео — оно появится в этой очереди.", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f), fontSize = 13.sp)
                                        }
                                    }
                                }
                            } else {
                                itemsIndexed(videos, key = { _, item -> item.uri }) { index, item ->
                                    Card(shape = RoundedCornerShape(if (compact) 14.dp else 20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                                        Row(Modifier.fillMaxWidth().padding(if (compact) 11.dp else 15.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                            Box(Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(Violet, Pink))), contentAlignment = Alignment.Center) {
                                                Icon(Icons.Default.Movie, null, tint = Color.White, modifier = Modifier.size(27.dp))
                                            }
                                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                Text(item.name, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                                Text(item.platforms.joinToString(" · ").ifBlank { "Платформы не выбраны" }, color = MaterialTheme.colorScheme.secondary, fontSize = 12.sp)
                                                Text(item.dateLabel, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f), fontSize = 11.sp)
                                            }
                                            IconButton(onClick = {
                                                videos = videos.toMutableList().also { it.removeAt(index) }
                                                persist()
                                                status = "Видео удалено из очереди."
                                            }) {
                                                Icon(Icons.Default.DeleteOutline, null, tint = Pink)
                                            }
                                        }
                                    }
                                }
                            }
                            item {
                                Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Icon(Icons.Default.Palette, null, tint = MaterialTheme.colorScheme.secondary)
                                            Text("Персонализация", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                        }
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Column(Modifier.weight(1f)) {
                                                Text("Тёмная тема", fontWeight = FontWeight.Medium)
                                                Text("Можно переключать в любое время", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                                            }
                                            Switch(checked = dark, onCheckedChange = {
                                                dark = it
                                                prefs.edit().putBoolean("dark", it).apply()
                                            })
                                        }
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Column(Modifier.weight(1f)) {
                                                Text("Компактный интерфейс", fontWeight = FontWeight.Medium)
                                                Text("Больше информации на экране", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                                            }
                                            Switch(checked = compact, onCheckedChange = {
                                                compact = it
                                                prefs.edit().putBoolean("compact", it).apply()
                                            })
                                        }
                                    }
                                }
                            }
                            item {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(Icons.Default.CloudUpload, null, tint = MaterialTheme.colorScheme.secondary)
                                    Text("Статус", fontWeight = FontWeight.Bold)
                                }
                                Text(status, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                                Text("Версия 1.0.0 · Myroniuk Studio", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.45f))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HeroHeader() {
    Box(
        Modifier.fillMaxWidth().height(206.dp).clip(RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF252C77), Color(0xFF6D45F5), Color(0xFFFF5C9A))))
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            drawCircle(Color(0xFFFFD778), radius = 38.dp.toPx(), center = Offset(w * 0.78f, h * 0.28f))
            val mountain1 = androidx.compose.ui.graphics.Path().apply {
                moveTo(0f, h * 0.78f); lineTo(w * 0.28f, h * 0.30f); lineTo(w * 0.47f, h * 0.69f)
                lineTo(w * 0.66f, h * 0.38f); lineTo(w, h * 0.78f); lineTo(w, h); lineTo(0f, h); close()
            }
            drawPath(mountain1, Brush.verticalGradient(listOf(Color(0xFF75E0D0), Color(0xFF166C8C)), startY = h * .3f, endY = h))
            val mountain2 = androidx.compose.ui.graphics.Path().apply {
                moveTo(0f, h * .86f); lineTo(w * .18f, h * .56f); lineTo(w * .39f, h * .83f)
                lineTo(w * .62f, h * .58f); lineTo(w * .82f, h * .84f); lineTo(w, h * .62f); lineTo(w, h); lineTo(0f, h); close()
            }
            drawPath(mountain2, Brush.verticalGradient(listOf(Color(0xFF322A72), Color(0xFF141C3B)), startY = h * .55f, endY = h))
        }
        Column(Modifier.align(Alignment.TopStart).padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Surface(color = Color.White.copy(alpha = 0.18f), shape = RoundedCornerShape(50)) {
                Text("CREATOR STUDIO", Modifier.padding(horizontal = 10.dp, vertical = 5.dp), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            }
            Text("Myroniuk\nStudio", color = Color.White, fontSize = 30.sp, lineHeight = 31.sp, fontWeight = FontWeight.ExtraBold)
            Text("Твоя идея. Твой контент.", color = Color.White.copy(alpha = .92f), fontSize = 13.sp)
        }
    }
}

private data class VideoItem(
    val uri: String,
    val name: String,
    val platforms: List<String>,
    val dateLabel: String
)

private fun saveVideos(items: List<VideoItem>): String {
    val array = JSONArray()
    items.forEach { item ->
        array.put(JSONObject().put("uri", item.uri).put("name", item.name)
            .put("platforms", JSONArray(item.platforms)).put("dateLabel", item.dateLabel))
    }
    return array.toString()
}

private fun loadVideos(raw: String): List<VideoItem> {
    return try {
        val array = JSONArray(raw)
        (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            val platforms = o.optJSONArray("platforms") ?: JSONArray()
            VideoItem(
                o.optString("uri"),
                o.optString("name", "Видео"),
                (0 until platforms.length()).map { platforms.optString(it) },
                o.optString("dateLabel", "Без даты")
            )
        }
    } catch (_: Exception) { emptyList() }
}
